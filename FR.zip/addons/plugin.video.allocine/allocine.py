# -*- coding: utf-8 -*-

# script constants
__plugin__ = "Allocine"
__addonID__ = "plugin.video.allocine"
__authors__ = "Ppic, Fanck"
__url__ = "http://code.google.com/p/passion-xbmc/"

__useragent__ = "Mozilla/5.0 (Windows; U; Windows NT 5.1; fr; rv:1.9.0.1) \
Gecko/2008070208 Firefox/3.0.1"


import urllib
import urllib2
import re
import os
import time
import xbmcgui
import xbmcplugin
import json
from traceback import print_exc

import xbmcaddon

__settings__ = xbmcaddon.Addon(__addonID__)
AddonPath = __settings__.getAddonInfo('path')

BASE_RESOURCE_PATH = os.path.join(AddonPath, "resources")
sys.path.append(os.path.join(BASE_RESOURCE_PATH, "lib"))
cache_dir = os.path.join(
        xbmc.translatePath(__settings__.getAddonInfo('profile')), "cache")
trailer_dir = __settings__.getSetting("trailer_path")
trailer_dir = xbmc.translatePath(trailer_dir)
dialog = xbmcgui.Dialog()
print "trailer dir: %s" % trailer_dir

tempfile = os.path.join(cache_dir, "data.html")
if not os.path.isdir(cache_dir):
    os.makedirs(cache_dir)

from convert import translate_string


# Handle quality
qualities = (104001, 104002, 104003, 104004)
__quality__ = qualities[int(__settings__.getSetting("quality"))]

# Handle dates
from datetime import date, datetime
from relativedelta import relativedelta

date_limit = {0: 3, 1: 6, 2: 12, 3: 0}  # months to go back or forth

date_limit_nowshowing = int(__settings__.getSetting("date_limit_nowshowing"))
date_limit_comingsoon = int(__settings__.getSetting("date_limit_comingsoon"))
today = date.today()
__date_limit_nowshowing__ = today - relativedelta(months=date_limit[date_limit_nowshowing])
__date_limit_comingsoon__ = today + relativedelta(months=date_limit[date_limit_comingsoon])

if __settings__.getSetting("skiprerelease") == 'true':
    __skiprerelease__ = True
else:
    __skiprerelease__ = False

# Display release date
if __settings__.getSetting("displayreleasedate") == 'true':
    __displayreleasedate__ = True
else:
    __displayreleasedate__ = False

# Handle title
if __settings__.getSetting("keeporiginaltitle") == 'true':
    __keeporiginaltitle__ = True
else:
    __keeporiginaltitle__ = False

# video types
__video_trailers__ = (31003, 31004, 31016, 31018)
__video_interviews__ = (31007, 31010)
__video_shows__ = (31011,)

# static parameters
__base_url__ = "http://api.allocine.fr/rest/v3/"
__partner_key__ = "aXBhZC12MQ"
__output_format__ = "json"
__media_format__ = "mp4"


def addLink(name, url, iconimage, c_items=None):
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png",
            thumbnailImage=iconimage)
    if c_items:
        liz.addContextMenuItems(c_items, replaceItems=True)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url,
            listitem=liz)
    return ok


def addDir(name, url, mode, iconimage, c_items=None, sortie=None):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png",
            thumbnailImage=iconimage)
    if c_items:
        liz.addContextMenuItems(c_items, replaceItems=True)
    if sortie:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Date": sortie})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u,
            listitem=liz, isFolder=True)
    return ok


def end_of_directory(OK):
    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=OK)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0: len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


def save_data(txt, temp=tempfile):
    try:
        if txt:
            file(temp, "w").write(repr(txt))
    except:
        print_exc()
        print "impossible d'enregistrer le fichier %s" % temp


def load_data(file_path):
    try:
        temp_data = eval(file(file_path, "r").read())
    except:
        print_exc()
        print "impossible de charger le fichier %s" % tempfile
        temp_data = ""
    return temp_data


def create_DB(url, dbname):
    DB_file = os.path.join(cache_dir, translate_string("%s.txt" % dbname))
    try:
        save_data(get_film_list(url), DB_file)
    except:
        print "impossible de créer la base %s" % DB_file
        print_exc()


def load_DB(dbname):
    DB_file = os.path.join(cache_dir, translate_string("%s.txt" % dbname))

    if os.path.isfile(DB_file):
        try:
            if time.time() - os.path.getmtime(DB_file) > 3600:
                print "base de plus de 24h, reconstruction..."
                return("")
            data = load_data(DB_file)
        except:
            print "impossible de charger %s" % DB_file
            print_exc()
            data = ""
    else:
        data = ""
    return data


def __getJson(method, query_string):
    "Make url calls to return Json parsed response"
    url = __base_url__ + method + '?' + urllib.urlencode(query_string)
    req = urllib2.Request(url)
    req.add_header('User-Agent', __useragent__)
    try:
        response = urllib.unquote_plus(urllib2.urlopen(req).read())
    except:
        # Retry once
        response = urllib.unquote_plus(urllib2.urlopen(req).read())
    return json.loads(response)


def __getVideo(video):
    # need to sort rendition before the magic can happen
    renditions = sorted(video['rendition'], key=lambda x:x.has_key('bandwidth') and x['bandwidth']['code'], reverse=True)
    # and that's what I love with python
    return max(renditions, key=lambda x:x.has_key('bandwidth') and x['bandwidth']['code'] <= __quality__)


def get_shows_list():
    "Get shows list"
    type_filter = "acshow"
    method = "termlist"
    query_string = {
            'partner': __partner_key__,
            'format': __output_format__,
            'filter': type_filter
    }
    result = __getJson(method, query_string)
    return result['feed']['term']


def get_videolist(search):
    "Get show's videos"
    method = "videolist"
    count = 100
    query_string = {
            'partner': __partner_key__,
            'filter': search,
            'format': __output_format__,
            'mediafmt': __media_format__,
            'count': count
    }

    loop = True
    processed = 0
    while loop:
        result = __getJson(method, query_string)
        if processed + int(result['feed']['count']) >= int(result['feed']['totalResults']):
            # last page
            loop = False
        else:
            processed += result['feed']['count']
            query_string['page'] = int(result['feed']['page']) + 1

        for episode in result['feed']['media']:
            video = __getVideo(episode)
            try:
                thumbnail = episode['thumbnail']['href']
            except KeyError:
                thumbnail = ''
            addLink(episode['title'].encode('utf8'), video['href'], thumbnail)


def get_movies_list(type_filter):
    "Get movies list"
    # TODO use updated
    method = "movielist"
    if type_filter == "nowshowing":
        order = "datedesc"
    else:
        order = "dateasc"
    count = 25
    page = 1
    query_string = {
            'partner': __partner_key__,
            'filter': type_filter,
            'format': __output_format__,
            'order': order,
            'count': count,
            'page': page,
            'striptags': 'synopsis'
    }

    if __keeporiginaltitle__:
        title = 'originalTitle'
    else:
        title = 'title'

    loop = True
    processed = 0
    while loop:
        result = __getJson(method, query_string)
        #print "Updated: " + result['feed']['updated']

        if processed + int(result['feed']['count']) >= int(result['feed']['totalResults']):
            # last page
            loop = False
        else:
            processed += result['feed']['count']
            query_string['page'] = int(result['feed']['page']) + 1

        for movie in result['feed']['movie']:
            if 'trailer' not in movie or 'productionYear' not in movie:
                continue
            if __skiprerelease__ and int(movie['productionYear']) < (int(movie['release']['releaseDate'][:4]) - 1):
                # minus one year to avoid skipping movies produced the year before
                continue
            if type_filter == "nowshowing" and __date_limit_nowshowing__ == date.today():
                pass
            elif type_filter == "comingsoon" and __date_limit_comingsoon__ == date.today():
                pass
            else:
                try:
                    releaseDate = datetime(*(time.strptime(movie['release']['releaseDate'], "%Y-%m-%d")[0:6])).date()
                    if type_filter == "nowshowing" and __date_limit_nowshowing__ > releaseDate:
                        loop = False
                        break
                    if type_filter == "comingsoon" and __date_limit_comingsoon__ < releaseDate:
                        loop = False
                        break
                except ValueError:
                    # can't process the date
                    pass
                except KeyError:
                    # no release date to test
                    pass
            try:
                poster = movie['poster']['href']
            except KeyError:
                poster = ""
            if 'release' in movie:
                if __displayreleasedate__:
                    movietitle = "%s - %s " % (movie['release']['releaseDate'].encode('utf8'), movie[title].encode('utf8'))
                else:
                    movietitle = movie[title].encode('utf8')
                addDir(movietitle, str(movie['code']), 2, poster)


def get_movie_videos(code, mode='trailers'):
    "Get trailers list"
    method = "movie"
    type_filter = "movie"
    profile = "large"
    query_string = {
            'partner': __partner_key__,
            'filter': type_filter,
            'format': __output_format__,
            'mediafmt': __media_format__,
            'profile': profile,
            'code': code
    }
    result = __getJson(method, query_string)

    if 'media' in result['movie']:
        for media in result['movie']['media']:
            if mode == 'trailers':
                interviews = False
                shows = False
                if media['class'] == 'video' and media['type']['code'] in __video_trailers__:
                    video = get_video(str(media['code']))
                    addLink(media['title'].encode('utf8'), video['href'], media['thumbnail']['href'])
                elif media['type']['code'] in __video_interviews__:
                    interviews = True
                elif media['type']['code'] in __video_shows__:
                    shows = True
            elif mode == 'interviews':
                if media['type']['code'] in __video_interviews__:
                    video = get_video(str(media['code']))
                    addLink(media['title'].encode('utf8'), video['href'], media['thumbnail']['href'])
            elif mode == 'shows':
                if media['type']['code'] in __video_shows__:
                    video = get_video(str(media['code']))
                    addLink(media['title'].encode('utf8'), video['href'], media['thumbnail']['href'])
    if mode == 'trailers':
        if interviews:
            addDir("Afficher les interviews", code, 5, "")
        if shows:
            addDir("Afficher les émissions", code, 6, "")


def get_video(code):
    "Get actual video"
    method = "media"
    query_string = {
            'partner': __partner_key__,
            'format': __output_format__,
            'mediafmt': __media_format__,
            'code': code
    }
    result = __getJson(method, query_string)
    return __getVideo(result['media'])


# menu principal:

params = get_params()
url = None
name = None
mode = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)

OK = True

if mode == None or url == None or len(url) < 1:  # menu principal
    addDir('Films - Au cinéma', "nowshowing", 1, "")
    addDir('Films - Prochainement', "comingsoon", 1, "")
    addDir("Séries Tv", "tvseries", 4, "")
    addDir("Émissions", "showslist", 3, "")
    addDir("Interviews", "interview", 4, "")
    # TODO: mon ciné

if mode == 1:
    get_movies_list(url)

if mode == 2:
    get_movie_videos(url)

if mode == 3:
    shows_list = get_shows_list()
    base_picture = "http://images.allocine.fr/r_120_x/commons/logos/"
    # list pictures which doesn't match their short names
    picture = {
        "laminute": base_picture + "Logos_minute_160x128.jpg",
        "tueursenseries": base_picture + "Logos_tes_160x128.jpg",
        "direct2dvd": base_picture + "Logos_D2D_160x128.jpg",
        "fauxraccord": base_picture + "Logos_FauxR_160x128.jpg",
        "pleindecine": base_picture + "Logos_p2c_160x128.jpg",
        "lesondecinema": base_picture + "Logos_lsdc_160x128.jpg",
        "gameincine": base_picture + "Logos_GIC_160x128.jpg",
        "skyfall": base_picture + "vignettesLogosEmissions_skyfall.jpg",
        "hobbittv": base_picture + "Logos_Hobbit_160x128.jpg",
        "nanarland": base_picture + "Logos__nanarland_160x128.jpg",
        "tapisrouge": base_picture + "vignettesLogosEmissions_tapisrouge.jpg",
        "mascenepreferee": base_picture + "Logos_mascene_160x128.jpg",
        "faceaufilm": base_picture + "Logos_faf_160x128.jpg"
    }
    for show in shows_list:
        try:
            image = picture["%s" % show['nameShort'].encode('utf8')]
        except KeyError:
            image = base_picture + "Logos_%s_160x128.jpg" % show['nameShort']
        addDir(show['$'].encode('utf8'), 'acshow:' + show['nameShort'], 4, image)

if mode == 4:
    get_videolist(url)

if mode == 5:
    get_movie_videos(url, 'interviews')

if mode == 6:
    get_movie_videos(url, 'shows')

end_of_directory(OK)
